﻿namespace WinFormsApp1
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            GenreMenu = new Button();
            ReviewMenu = new Button();
            BundleMenu = new Button();
            UserMenu = new Button();
            label1 = new Label();
            GameMenu = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            textBox3 = new TextBox();
            menuStrip2 = new MenuStrip();
            storeToolStripMenuItem = new ToolStripMenuItem();
            gamesToolStripMenuItem = new ToolStripMenuItem();
            viewsToolStripMenuItem = new ToolStripMenuItem();
            libraryToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1 = new MenuStrip();
            menuStrip2.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // GenreMenu
            // 
            GenreMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            GenreMenu.Location = new Point(871, 217);
            GenreMenu.Name = "GenreMenu";
            GenreMenu.Size = new Size(125, 78);
            GenreMenu.TabIndex = 19;
            GenreMenu.Text = "Genre Menu";
            GenreMenu.UseVisualStyleBackColor = true;
            GenreMenu.Click += GenreMenu_Click;
            // 
            // ReviewMenu
            // 
            ReviewMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            ReviewMenu.Location = new Point(871, 365);
            ReviewMenu.Name = "ReviewMenu";
            ReviewMenu.Size = new Size(125, 78);
            ReviewMenu.TabIndex = 18;
            ReviewMenu.Text = "Review Menu";
            ReviewMenu.UseVisualStyleBackColor = true;
            ReviewMenu.Click += ReviewMenu_Click;
            // 
            // BundleMenu
            // 
            BundleMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            BundleMenu.Location = new Point(250, 365);
            BundleMenu.Name = "BundleMenu";
            BundleMenu.Size = new Size(125, 78);
            BundleMenu.TabIndex = 17;
            BundleMenu.Text = "Bundle Menu";
            BundleMenu.UseVisualStyleBackColor = true;
            BundleMenu.Click += BundleMenu_Click;
            // 
            // UserMenu
            // 
            UserMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            UserMenu.Location = new Point(569, 125);
            UserMenu.Name = "UserMenu";
            UserMenu.Size = new Size(125, 78);
            UserMenu.TabIndex = 16;
            UserMenu.Text = "User Menu";
            UserMenu.UseVisualStyleBackColor = true;
            UserMenu.Click += UserMenu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic", 30F, FontStyle.Bold);
            label1.Location = new Point(528, 25);
            label1.Name = "label1";
            label1.Size = new Size(183, 64);
            label1.TabIndex = 15;
            label1.Text = "Steam";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // GameMenu
            // 
            GameMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GameMenu.Location = new Point(250, 217);
            GameMenu.Name = "GameMenu";
            GameMenu.Size = new Size(125, 78);
            GameMenu.TabIndex = 14;
            GameMenu.Text = "Game Menu";
            GameMenu.UseVisualStyleBackColor = true;
            GameMenu.Click += GameMenu_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(1071, 25);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 21;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(1071, 68);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 22;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(987, 32);
            label2.Name = "label2";
            label2.Size = new Size(76, 20);
            label2.TabIndex = 23;
            label2.Text = "username:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(999, 75);
            label3.Name = "label3";
            label3.Size = new Size(64, 20);
            label3.TabIndex = 24;
            label3.Text = "balance:";
            // 
            // button1
            // 
            button1.Location = new Point(987, 103);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 26;
            button1.Text = "add funds:";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(1087, 103);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(49, 27);
            textBox3.TabIndex = 27;
            // 
            // menuStrip2
            // 
            menuStrip2.ImageScalingSize = new Size(20, 20);
            menuStrip2.Items.AddRange(new ToolStripItem[] { storeToolStripMenuItem });
            menuStrip2.Location = new Point(0, 0);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(1223, 28);
            menuStrip2.TabIndex = 28;
            menuStrip2.Text = "menuStrip2";
            // 
            // storeToolStripMenuItem
            // 
            storeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { gamesToolStripMenuItem });
            storeToolStripMenuItem.ImageTransparentColor = Color.White;
            storeToolStripMenuItem.Name = "storeToolStripMenuItem";
            storeToolStripMenuItem.Size = new Size(58, 24);
            storeToolStripMenuItem.Text = "Store";
            // 
            // gamesToolStripMenuItem
            // 
            gamesToolStripMenuItem.BackColor = Color.FromArgb(150, 120, 240);
            gamesToolStripMenuItem.Name = "gamesToolStripMenuItem";
            gamesToolStripMenuItem.Size = new Size(137, 26);
            gamesToolStripMenuItem.Text = "Games";
            gamesToolStripMenuItem.Click += gamesToolStripMenuItem_Click;
            // 
            // viewsToolStripMenuItem
            // 
            viewsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { libraryToolStripMenuItem });
            viewsToolStripMenuItem.Name = "viewsToolStripMenuItem";
            viewsToolStripMenuItem.Size = new Size(61, 24);
            viewsToolStripMenuItem.Text = "Views";
            // 
            // libraryToolStripMenuItem
            // 
            libraryToolStripMenuItem.BackColor = Color.FromArgb(150, 120, 240);
            libraryToolStripMenuItem.Name = "libraryToolStripMenuItem";
            libraryToolStripMenuItem.Size = new Size(137, 26);
            libraryToolStripMenuItem.Text = "Library";
            libraryToolStripMenuItem.Click += libraryToolStripMenuItem_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { viewsToolStripMenuItem });
            menuStrip1.Location = new Point(0, 28);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Size = new Size(1223, 28);
            menuStrip1.TabIndex = 25;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.Click += menuStrip1_Click;
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(1223, 637);
            Controls.Add(textBox3);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(GenreMenu);
            Controls.Add(ReviewMenu);
            Controls.Add(BundleMenu);
            Controls.Add(UserMenu);
            Controls.Add(label1);
            Controls.Add(GameMenu);
            Controls.Add(menuStrip1);
            Controls.Add(menuStrip2);
            ForeColor = SystemColors.ActiveCaptionText;
            MainMenuStrip = menuStrip1;
            Name = "MainMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button GenreMenu;
        private Button ReviewMenu;
        private Button BundleMenu;
        private Button UserMenu;
        private Label label1;
        private Button GameMenu;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private Button button1;
        private TextBox textBox3;
        private MenuStrip menuStrip2;
        private ToolStripMenuItem storeToolStripMenuItem;
        private ToolStripMenuItem gamesToolStripMenuItem;
        private ToolStripMenuItem viewsToolStripMenuItem;
        private ToolStripMenuItem libraryToolStripMenuItem;
        private MenuStrip menuStrip1;
    }
}