﻿using Steam.Data.Models;
using Steam.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class GenreMenu : Form
    {
        public GenreMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                using (var db = new SteamDbContext())
                {
                    string filePath = "genres.txt"; // или "Resources/genres.txt"
                    if (!File.Exists(filePath))
                    {
                        MessageBox.Show("Файлът genres.txt не е намерен!");
                        return;
                    }

                    var lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        var genre = new Genres
                        {
                            Name = line.Trim()
                        };

                        if (!db.Genres.Any(g => g.Name == genre.Name))
                        {
                            db.Genres.Add(genre);
                        }

                    }

                    db.SaveChanges();
                    MessageBox.Show("Жанровете бяха успешно добавени!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка: " + ex.Message);
            }
        }
    }
}
