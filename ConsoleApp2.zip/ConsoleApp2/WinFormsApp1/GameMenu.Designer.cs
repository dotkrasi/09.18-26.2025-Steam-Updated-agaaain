﻿namespace WinFormsApp1
{
    partial class GameMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            listBoxLibrary = new ListBox();
            button3 = new Button();
            button5 = new Button();
            textBoxGameId = new TextBox();
            textBoxTitle = new TextBox();
            textBoxDescription = new TextBox();
            textBoxDeveloper = new TextBox();
            textBoxPublisher = new TextBox();
            textBoxRating = new TextBox();
            buttonUpdateGame = new Button();
            textBoxGenreId = new TextBox();
            textBoxPrice = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Control;
            button1.Location = new Point(75, 123);
            button1.Name = "button1";
            button1.Size = new Size(105, 62);
            button1.TabIndex = 0;
            button1.Text = "Add Games";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(75, 327);
            button2.Name = "button2";
            button2.Size = new Size(105, 62);
            button2.TabIndex = 1;
            button2.Text = "Show all games ";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // listBoxLibrary
            // 
            listBoxLibrary.FormattingEnabled = true;
            listBoxLibrary.Location = new Point(330, 45);
            listBoxLibrary.Name = "listBoxLibrary";
            listBoxLibrary.Size = new Size(502, 224);
            listBoxLibrary.TabIndex = 2;
            listBoxLibrary.SelectedIndexChanged += listBoxLibrary_SelectedIndexChanged;
            // 
            // button3
            // 
            button3.Location = new Point(75, 259);
            button3.Name = "button3";
            button3.Size = new Size(105, 62);
            button3.TabIndex = 6;
            button3.Text = "Remove Games";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button5
            // 
            button5.Location = new Point(75, 191);
            button5.Name = "button5";
            button5.Size = new Size(105, 62);
            button5.TabIndex = 5;
            button5.Text = "Update Games";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBoxGameId
            // 
            textBoxGameId.Location = new Point(349, 312);
            textBoxGameId.Name = "textBoxGameId";
            textBoxGameId.Size = new Size(125, 27);
            textBoxGameId.TabIndex = 7;
            // 
            // textBoxTitle
            // 
            textBoxTitle.Location = new Point(349, 345);
            textBoxTitle.Name = "textBoxTitle";
            textBoxTitle.Size = new Size(125, 27);
            textBoxTitle.TabIndex = 8;
            // 
            // textBoxDescription
            // 
            textBoxDescription.Location = new Point(349, 378);
            textBoxDescription.Name = "textBoxDescription";
            textBoxDescription.Size = new Size(125, 27);
            textBoxDescription.TabIndex = 9;
            // 
            // textBoxDeveloper
            // 
            textBoxDeveloper.Location = new Point(349, 411);
            textBoxDeveloper.Name = "textBoxDeveloper";
            textBoxDeveloper.Size = new Size(125, 27);
            textBoxDeveloper.TabIndex = 10;
            // 
            // textBoxPublisher
            // 
            textBoxPublisher.Location = new Point(674, 312);
            textBoxPublisher.Name = "textBoxPublisher";
            textBoxPublisher.Size = new Size(125, 27);
            textBoxPublisher.TabIndex = 11;
            // 
            // textBoxRating
            // 
            textBoxRating.Location = new Point(674, 345);
            textBoxRating.Name = "textBoxRating";
            textBoxRating.Size = new Size(125, 27);
            textBoxRating.TabIndex = 12;
            // 
            // buttonUpdateGame
            // 
            buttonUpdateGame.Location = new Point(532, 442);
            buttonUpdateGame.Name = "buttonUpdateGame";
            buttonUpdateGame.Size = new Size(94, 29);
            buttonUpdateGame.TabIndex = 13;
            buttonUpdateGame.Text = "Update";
            buttonUpdateGame.UseVisualStyleBackColor = true;
            buttonUpdateGame.Click += buttonUpdateGame_Click;
            // 
            // textBoxGenreId
            // 
            textBoxGenreId.Location = new Point(674, 378);
            textBoxGenreId.Name = "textBoxGenreId";
            textBoxGenreId.Size = new Size(125, 27);
            textBoxGenreId.TabIndex = 14;
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(674, 411);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.Size = new Size(125, 27);
            textBoxPrice.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(316, 319);
            label1.Name = "label1";
            label1.Size = new Size(27, 20);
            label1.TabIndex = 16;
            label1.Text = "ID:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(302, 352);
            label2.Name = "label2";
            label2.Size = new Size(41, 20);
            label2.TabIndex = 17;
            label2.Text = "Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 385);
            label3.Name = "label3";
            label3.Size = new Size(88, 20);
            label3.TabIndex = 18;
            label3.Text = "Description:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(262, 418);
            label4.Name = "label4";
            label4.Size = new Size(81, 20);
            label4.TabIndex = 19;
            label4.Text = "Developer:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(596, 315);
            label5.Name = "label5";
            label5.Size = new Size(72, 20);
            label5.TabIndex = 20;
            label5.Text = "Publisher:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(613, 352);
            label6.Name = "label6";
            label6.Size = new Size(55, 20);
            label6.TabIndex = 21;
            label6.Text = "Rating:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(604, 385);
            label7.Name = "label7";
            label7.Size = new Size(64, 20);
            label7.TabIndex = 22;
            label7.Text = "GenreId:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(624, 419);
            label8.Name = "label8";
            label8.Size = new Size(44, 20);
            label8.TabIndex = 23;
            label8.Text = "Price:";
            // 
            // GameMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(939, 542);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxPrice);
            Controls.Add(textBoxGenreId);
            Controls.Add(buttonUpdateGame);
            Controls.Add(textBoxRating);
            Controls.Add(textBoxPublisher);
            Controls.Add(textBoxDeveloper);
            Controls.Add(textBoxDescription);
            Controls.Add(textBoxTitle);
            Controls.Add(textBoxGameId);
            Controls.Add(button3);
            Controls.Add(button5);
            Controls.Add(listBoxLibrary);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "GameMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GameMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private ListBox listBoxLibrary;
        private Button button3;
        private Button button5;
        private TextBox textBoxGameId;
        private TextBox textBoxTitle;
        private TextBox textBoxDescription;
        private TextBox textBoxDeveloper;
        private TextBox textBoxPublisher;
        private TextBox textBoxRating;
        private Button buttonUpdateGame;
        private TextBox textBoxGenreId;
        private TextBox textBoxPrice;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
    }
}