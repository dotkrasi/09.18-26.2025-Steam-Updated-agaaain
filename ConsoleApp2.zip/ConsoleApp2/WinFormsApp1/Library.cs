﻿using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Library : Form
    {
        private readonly SteamDbContext _context;
        private readonly Queries _queries;
        private readonly int _userId;

        public Library(int userId)
        {
            InitializeComponent();

            _context = new SteamDbContext();
            _queries = new Queries(_context);
            _userId = userId;

            LoadUserLibrary();
        }

        public void LoadUserLibrary()
        {

            listBox1.Items.Clear();

            var library = _queries.GetUserLibrary(_userId);

            if (!library.Any())
            {
                listBox1.Items.Add("Library is empty.");
                return;
            }

            foreach (var game in library)
            {
                listBox1.Items.Add($"{game.Title} ({game.Genre?.Name}) - {game.Price}$");
            }

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session.CurrentUser == null)
                {
                    MessageBox.Show("No user is logged in!");
                    return;
                }

                using (var db = new SteamDbContext())
                {
                    var query = new Queries(db);
                    var games = query.GetUserLibrary(Session.CurrentUser.UserId);

                    listBox1.Items.Clear();

                    if (games.Count == 0)
                    {
                        listBox1.Items.Add("Your library is empty.");
                    }
                    else
                    {
                        foreach (var game in games)
                        {
                            listBox1.Items.Add($"{game.Title} - {game.Developer} - {game.Price} USD");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading library: " + ex.Message);
            }
        }

        private void Library_Load(object sender, EventArgs e)
        {

        }
    }
}
