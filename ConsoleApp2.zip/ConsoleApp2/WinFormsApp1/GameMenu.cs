﻿using Steam.Data.Models;
using Steam.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Steam.Core;
using Microsoft.EntityFrameworkCore;

namespace WinFormsApp1
{
    public partial class GameMenu : Form
    {

        private readonly SteamDbContext _context;
        private readonly Queries _queries;

        public GameMenu()
        {
            InitializeComponent();
            _context = new SteamDbContext();
            _queries = new Queries(_context);
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            label6.Hide();
            label7.Hide();
            label8.Hide();
            textBoxDescription.Hide();
            textBoxDeveloper.Hide();
            textBoxGameId.Hide();
            textBoxGenreId.Hide();
            textBoxPrice.Hide();
            textBoxPublisher.Hide();
            textBoxRating.Hide();
            textBoxTitle.Hide();
            buttonUpdateGame.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                using (var db = new SteamDbContext())
                {
                    string filePath = "games.txt";
                    if (!File.Exists(filePath))
                    {
                        MessageBox.Show("Файлът games.txt не е намерен!");
                        return;
                    }

                    var lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        var parts = line.Split(';');
                        if (parts.Length < 7) continue;

                        var game = new Games
                        {
                            Title = parts[0],
                            Description = parts[1],
                            Developer = parts[2],
                            Publisher = parts[3],
                            Rating = int.Parse(parts[4]),
                            Price = double.Parse(parts[5]),
                            genreId = int.Parse(parts[6])
                        };

                        db.Games.Add(game);
                    }

                    db.SaveChanges();
                    MessageBox.Show("Игрите бяха успешно добавени!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBoxLibrary.Items.Clear();
            /*    int userId = Session.CurrentUser.UserId;
                var library = _queries.GetUserLibrary(userId);
    */
            var allGames = _context.Games
               .OrderBy(g => g.Title)
               .ToList();

            if (!allGames.Any())
            {
                listBoxLibrary.Items.Add("No games found.");
                return;
            }
            foreach (var game in allGames)
            {
                listBoxLibrary.Items.Add($"{game.Title} ({game.Genre?.Name}) - {game.Price}$");
            }

        }

        private void listBoxLibrary_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Show();
            label3.Show();
            label4.Show();
            label5.Show();
            label6.Show();
            label7.Show();
            label8.Show();
            textBoxDescription.Show();
            textBoxDeveloper.Show();
            textBoxGameId.Show();
            textBoxGenreId.Show();
            textBoxPrice.Show();
            textBoxPublisher.Show();
            textBoxRating.Show();   
            textBoxTitle.Show();
            buttonUpdateGame.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void buttonUpdateGame_Click(object sender, EventArgs e)
        {
            try
            {
                int gameId = int.Parse(textBoxGameId.Text);
                string newTitle = textBoxTitle.Text;
                string newDescription = textBoxDescription.Text;
                string newDeveloper = textBoxDeveloper.Text;
                string newPublisher = textBoxPublisher.Text;
                int newRating = int.Parse(textBoxRating.Text);
                int newGenreId = int.Parse(textBoxGenreId.Text);
                double newPrice = double.Parse(textBoxPrice.Text);

                using (var db = new SteamDbContext())
                {
                    var gamesController = new GamesController(db);
                    gamesController.UpdateGame(gameId, newTitle, newDescription, newDeveloper, newPublisher, newRating, newGenreId, newPrice);
                }

                MessageBox.Show("Game updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating game: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
