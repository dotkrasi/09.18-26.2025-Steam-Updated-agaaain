﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Steam.Data.Models;

namespace Steam.Data
{
    public class SteamDbContext : DbContext
    {
        public SteamDbContext()
        {

        }

        public SteamDbContext(DbContextOptions<SteamDbContext> options) : base(options)
        {

        }

        public DbSet<Games> Games { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Reviews> Reviews { get; set; }
        public DbSet<Genres> Genres { get; set; }
        public DbSet<Bundles> Bundles { get; set; }
        public DbSet<GamesBundles> GamesBundles { get; set; }
        public DbSet<UserGames> UserGames { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Steam;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            // One-to-Many: Genres ↔ Games
            modelBuilder.Entity<Games>()
                .HasOne(g => g.Genre)
                .WithMany(ge => ge.Games)
                .HasForeignKey(g => g.genreId)
                .OnDelete(DeleteBehavior.Restrict);

            // One-to-Many: Users ↔ Reviews
            modelBuilder.Entity<Reviews>()
                .HasOne(r => r.Users)
                .WithMany(u => u.Reviews)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-Many: Games ↔ Reviews
            modelBuilder.Entity<Reviews>()
                .HasOne(r => r.Games)
                .WithMany(g => g.Reviews)
                .HasForeignKey(r => r.GameId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
