﻿using Microsoft.EntityFrameworkCore;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Steam.Core
{
    public class Queries
    {


        private readonly SteamDbContext _context;

        public Queries(SteamDbContext context)
        {
            _context = context;
        }

        // Добавяне на игра в библиотеката на потребител
        public void AddGameToLibrary(int userId, int gameId)
        {
            var user = _context.Users.Find(userId);
            var game = _context.Games.Find(gameId);

            if (user == null) throw new ArgumentException("User not found.");
            if (game == null) throw new ArgumentException("Game not found.");

            if (_context.UserGames.Any(ug => ug.UserId == userId && ug.GameId == gameId))
            {
                Console.WriteLine("Game already in library.");
                return;
            }

            var userGame = new UserGames
            {
                UserId = userId,
                GameId = gameId
            };

            _context.UserGames.Add(userGame);
            _context.SaveChanges();
            Console.WriteLine($"Game '{game.Title}' added to {user.Username}'s library.");
        }

        // Връща библиотеката на потребителя
        public List<Games> GetUserLibrary(int userId)
        {
                var library = _context.UserGames
        .Where(ug => ug.UserId == userId)
        .Include(ug => ug.game)       // зареждаме играта
        .ThenInclude(g => g.Genre)    // зареждаме жанра на играта
        .Select(ug => ug.game)
        .ToList();

            return library;
        }

        // Добавяне на средства към акаунта
        public void AddBalance(int userId, double amount)
        {
            if (amount <= 0) throw new ArgumentException("Amount must be positive.");

            var user = _context.Users.Find(userId);
            if (user == null) throw new ArgumentException("User not found.");

            user.Balance += amount;
            _context.SaveChanges();
            Console.WriteLine($"Added {amount} to {user.Username}'s balance. New balance: {user.Balance}");
        }

        // Връща всички игри от даден жанр
        public List<Games> GetGamesByGenre(string genreName)
        {
            var games = _context.Games
                .Where(g => g.Genre.Name.ToLower().Contains(genreName.ToLower()))
                .ToList();

            return games;
        }

        // Търсене на игри по ключова дума (title, description, developer, publisher)
        public List<Games> SearchGames(string keyword)
        {
            keyword = keyword.ToLower();
            var games = _context.Games
                .Where(g =>
                    g.Title.ToLower().Contains(keyword) ||
                    g.Description.ToLower().Contains(keyword) ||
                    g.Developer.ToLower().Contains(keyword) ||
                    g.Publisher.ToLower().Contains(keyword))
                .ToList();

            return games;
        }

        // Най-високо оценените игри
        public List<Games> GetTopRatedGames(int top = 5)
        {
            return _context.Games
                .OrderByDescending(g => g.Rating)
                .Take(top)
                .ToList();
        }

        // Взема всички ревюта за дадена игра
        public List<Reviews> GetReviewsForGame(int gameId)
        {
            return _context.Reviews
                .Where(r => r.GameId == gameId)
                .ToList();
        }

        // Взема всички ревюта от даден потребител
        public List<Reviews> GetReviewsByUser(int userId)
        {
            return _context.Reviews
                .Where(r => r.UserId == userId)
                .ToList();
        }

        // Средна оценка на игра
        public double GetAverageRating(int gameId)
        {
            var reviews = _context.Reviews
                .Where(r => r.GameId == gameId)
                .ToList();

            if (!reviews.Any()) return 0;

            return reviews.Average(r => r.Rating);
        }

        // Купуване на bundle
        public void BuyBundle(int userId, int bundleId)
        {
            var user = _context.Users.Find(userId);
            var bundle = _context.Bundles.Find(bundleId);

            if (user == null) throw new ArgumentException("User not found.");
            if (bundle == null) throw new ArgumentException("Bundle not found.");

            if (user.Balance < bundle.Price)
            {
                Console.WriteLine("Insufficient balance.");
                return;
            }

            // Добавяне на всички игри от bundle в библиотеката
            var bundleGames = _context.GamesBundles
                .Where(gb => gb.bundleId == bundleId)
                .Select(gb => gb.Game)
                .ToList();

            foreach (var game in bundleGames)
            {
                if (!_context.UserGames.Any(ug => ug.UserId == userId && ug.GameId == game.GameId))
                {
                    _context.UserGames.Add(new UserGames
                    {
                        UserId = userId,
                        GameId = game.GameId
                    });
                }
            }

            user.Balance -= bundle.Price;
            _context.SaveChanges();

            Console.WriteLine($"Bundle '{bundle.Name}' purchased successfully! Remaining balance: {user.Balance}");
        }


        public void BuyGame(int userId, string gameTitle)
        {
            var user = _context.Users.Find(userId);
            if (user == null) throw new Exception("User not found");

            var game = _context.Games.FirstOrDefault(g => g.Title == gameTitle);
            if (game == null) throw new Exception("Game not found");

            if (user.Balance < game.Price)
            {
                throw new Exception("Not enough balance to buy this game!");
            }

            // проверка дали вече я има
            bool alreadyOwned = _context.UserGames.Any(ug => ug.UserId == userId && ug.GameId == game.GameId);
            if (alreadyOwned)
            {
                throw new Exception("User already owns this game!");
            }

            // намаляване на баланса
            user.Balance -= game.Price;

            // добавяне в библиотеката
            var userGame = new UserGames
            {
                UserId = userId,
                GameId = game.GameId
            };

            _context.UserGames.Add(userGame);
            _context.Users.Update(user);
            _context.SaveChanges();
        }

    }
}

