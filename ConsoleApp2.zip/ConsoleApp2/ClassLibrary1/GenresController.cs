﻿using Steam.Data;
using Steam.Data.Models;
using System;
using System.Linq;

namespace Steam.Core
{
    public class GenresController
    {
        private readonly SteamDbContext _context;

        public GenresController(SteamDbContext context)
        {
            _context = context;
        }

        public void AddGenre(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException("Genre name cannot be null or empty.");
            }

            var genre = new Genres
            {
                Name = name
            };

            try
            {
                _context.Genres.Add(genre);
                _context.SaveChanges();
                Console.WriteLine("Successfully added genre!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while adding the genre.", ex);
            }
        }

        public void UpdateGenre(int genreId, string newName)
        {
            var genre = _context.Genres.Find(genreId);
            if (genre == null)
            {
                throw new ArgumentException("Genre not found.");
            }
            if (string.IsNullOrEmpty(newName))
            {
                throw new ArgumentException("Genre name cannot be null or empty.");
            }

            genre.Name = newName;

            try
            {
                _context.Genres.Update(genre);
                _context.SaveChanges();
                Console.WriteLine("Genre updated successfully!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the genre.", ex);
            }
        }

        public void RemoveGenre(int genreId)
        {
            var genre = _context.Genres.Find(genreId);
            if (genre == null)
            {
                Console.WriteLine("This genre doesn't exist.");
                return;
            }

            try
            {
                _context.Genres.Remove(genre);
                _context.SaveChanges();
                Console.WriteLine("Genre removed successfully!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while removing the genre.", ex);
            }
        }

        public void ReadGenres()
        {
            var genres = _context.Genres.ToList();


            Console.WriteLine("Genres");
            foreach (var genre in genres)
            {
                Console.WriteLine($"ID: {genre.GenreId} | Name: {genre.Name}");
            }
        }
    }
}
