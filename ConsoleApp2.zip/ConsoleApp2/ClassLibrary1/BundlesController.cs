﻿using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Steam.Core
{
    public class BundlesController
    {

        private readonly SteamDbContext _context;

        public BundlesController(SteamDbContext context)
        {
            _context = context;
        }


        public void AddBundle(string name, double price, List<GamesBundles> games)
        {
            if (string.IsNullOrEmpty(name)) { throw new ArgumentException("Name cannot be empty."); }
            if (games == null) { throw new ArgumentException("Games cannot be null."); }

            var bundle = new Bundles
            {
                Name = name,
                Price = price,
                gamesBundles = games
            };

            try
            {
                _context.Bundles.Add(bundle);
                _context.SaveChanges();
                Console.WriteLine("Successfully added bundle!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while adding the bundle.", ex);
            }
        }

        public void UpdateBundle(int bundleId, string newName, double newPrice, List<GamesBundles> newGames)
        {
            var bundle = _context.Bundles.Find(bundleId);
            if (bundle == null) throw new ArgumentException("Bundle not found.");

            if (newName == null) { throw new ArgumentException("Name cannot be empty"); }
            if (newGames == null) { throw new ArgumentException("Games cannot be null."); }


            bundle.Name = newName;
            bundle.Price = newPrice;
            bundle.gamesBundles = newGames;


            try
            {
                _context.Bundles.Update(bundle);
                _context.SaveChanges();
                Console.WriteLine("Successfully updated bundle!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the bundle.", ex);
            }

        }


        public void RemoveBundle(int bundleId)
        {
            var bundle = _context.Bundles.Find(bundleId);
            if (bundle == null) throw new ArgumentException("Bundle doesn't exist");

            try
            {
                _context.Bundles.Remove(bundle);
                _context.SaveChanges();
                Console.WriteLine("Successfully removed bundle.");
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Error occured: ", ex);
            }

        }

        public void ReadBundles()
        {
            var bundles = _context.Bundles.ToList();

            if (!bundles.Any())
            {
                Console.WriteLine("No bundles found.");
                return;
            }

            Console.WriteLine("=== Bundle ===");
            foreach (var bundle in bundles)
            {
                Console.WriteLine($"ID: {bundle.BundleId}");
                Console.WriteLine($"Name: {bundle.Name}");
                Console.WriteLine($"Price: {bundle.Price}");
                Console.WriteLine("----------------------------");
            }
        }

    }
}
